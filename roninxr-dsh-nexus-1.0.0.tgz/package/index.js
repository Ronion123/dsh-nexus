/**
 * Host half of the "Nexus" pet-pack bundle.
 *
 * This bundle ships no pet engine of its own. It installs a dsh-pet "pet pack"
 * (config + VP9-alpha animations + pose stickers + avatar + character sheet) into
 * dsh-pet's user data root; dsh-pet then renders it with its full feature set:
 * drag/throw physics, the right-click action menu, work-status linkage to session
 * events, whisper/chat bubbles, balance animations, sleeping and multi-pet support.
 *
 * Installation is content-addressed and idempotent: a file is written only when its
 * bytes differ, so a user's hand-edited pack config survives every Host boot. A
 * byte-stable marker records the bundle version and the clips it installed, which is
 * what lets a later version remove clips it no longer ships without touching files
 * the user added.
 */
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';

const PACKAGE_DIR = dirname(fileURLToPath(import.meta.url));
const PACK_DATA_DIR = join(PACKAGE_DIR, 'pet-pack');
const MARKER_NAME = '.dsh-nexus.json';
const BUNDLE_VERSION = '2.0.0';

/** dsh-pet resolves its data root as join(resolveDshHome(), 'dsh-pet'). */
function resolveDshHome() {
  const explicit = process.env.DSH_HOME;
  if (explicit && explicit.trim() !== '') return explicit.trim();
  return join(homedir(), '.dsh');
}

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

/** Copy a directory tree, writing only changed files. Mutates the summary. */
function installTree(srcDir, destDir, summary) {
  if (!existsSync(srcDir)) return;
  mkdirSync(destDir, { recursive: true });
  for (const entry of readdirSync(srcDir, { withFileTypes: true })) {
    const src = join(srcDir, entry.name);
    const dest = join(destDir, entry.name);
    if (entry.isDirectory()) {
      installTree(src, dest, summary);
      continue;
    }
    if (!entry.isFile()) continue;
    const bytes = readFileSync(src);
    if (existsSync(dest) && statSync(dest).isFile() && sha256(readFileSync(dest)) === sha256(bytes)) {
      summary.unchanged += 1;
      continue;
    }
    writeFileSync(dest, bytes);
    summary.written += 1;
  }
}

/** Remove clips a previous version installed but this version no longer ships. */
function removeStaleClips(animDir, previous, current) {
  if (!previous || !Array.isArray(previous.clips)) return 0;
  const keep = new Set(current);
  let removed = 0;
  for (const name of previous.clips) {
    if (keep.has(name)) continue;
    const target = resolve(animDir, name);
    if (dirname(target) !== resolve(animDir)) continue; // never leave the pack directory
    try {
      if (existsSync(target)) {
        rmSync(target);
        removed += 1;
      }
    } catch {
      // A file locked by a decoder is harmless; the next boot retries.
    }
  }
  return removed;
}

function listClips(dir) {
  if (!existsSync(dir)) return [];
  return readdirSync(dir).filter((name) => name.endsWith('.webm')).sort();
}

/** Install the pet pack into dsh-pet's user data directory. */
function installPetPack() {
  const userRoot = join(resolveDshHome(), 'dsh-pet');
  const petDir = join(userRoot, 'pet');
  const animDir = join(petDir, 'nexus-animation');
  const memeDir = join(petDir, 'nexus-memes');
  const markerPath = join(petDir, MARKER_NAME);

  let previous;
  try {
    previous = JSON.parse(readFileSync(markerPath, 'utf8'));
  } catch {
    previous = undefined;
  }

  const summary = { ok: true, written: 0, unchanged: 0, removed: 0, root: userRoot };
  try {
    mkdirSync(petDir, { recursive: true });
    mkdirSync(animDir, { recursive: true });
    mkdirSync(memeDir, { recursive: true });

    installTree(join(PACK_DATA_DIR, 'config'), petDir, summary);
    installTree(join(PACK_DATA_DIR, 'animation'), animDir, summary);
    installTree(join(PACK_DATA_DIR, 'memes'), memeDir, summary);

    const clips = listClips(animDir);
    summary.removed = removeStaleClips(animDir, previous, clips);

    // No timestamp: a byte-stable marker keeps repeated boots fully idempotent.
    const marker = JSON.stringify({ version: BUNDLE_VERSION, bundle: 'dsh-nexus', clips }, null, 2) + '\n';
    if (!existsSync(markerPath) || readFileSync(markerPath, 'utf8') !== marker) {
      writeFileSync(markerPath, marker);
      summary.written += 1;
    }
  } catch (error) {
    summary.ok = false;
    summary.reason = error instanceof Error ? error.message : String(error);
  }
  return summary;
}

export const inject = [];

export function apply(ctx) {
  const result = installPetPack();
  try {
    const info = ctx?.logger?.info;
    const warn = ctx?.logger?.warn;
    if (result.ok) {
      if (typeof info === 'function') info(`[dsh-nexus] pet pack ready: ${JSON.stringify(result)}`);
    } else if (typeof warn === 'function') {
      // Non-fatal: the Host must keep booting even when the user data dir is read-only.
      warn(`[dsh-nexus] pet pack install failed: ${result.reason}`);
    }
  } catch {
    // A Host without a usable logger still works; the pack is simply not installed.
  }
  // One-shot boot-time effect: nothing to dispose.
  return () => {};
}
